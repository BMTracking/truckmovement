export default interface IData {
    code:number
    msg?:string
    data:any
}