export default interface IMessage {
    code:number
    msg:string
}