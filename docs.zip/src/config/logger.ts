export default {
	console: {
		level: 'debug'
	},
	service: 'typeorm-db-adapter'
};