'use strict'
/**
 * BankModel
 */
export default interface BankModel{
    id:any;
    name:string ;
    code:string;
    createdDate:Date;
    updateDate:Date;
    deleteDate:Date;
}