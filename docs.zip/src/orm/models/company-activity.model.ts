'use strict'
/**
 * CompanyActivityModel
 */
export default interface CompanyActivityModel{
    id?:any;
    company_id:any;
    activity_id:any;
    createdAt?:Date;
    updatedAt?:Date;
    deletedAt?:Date;
}