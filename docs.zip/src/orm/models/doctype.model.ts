'use strict'
/**
 * DoctypeModel
 */
export default interface DoctypeModel{
    id?:any;
    country_id?:any;
    name:string;
    description?:string;
    createdDate?:Date;
    updateDate?:Date;
    deleteDate?:Date;
}