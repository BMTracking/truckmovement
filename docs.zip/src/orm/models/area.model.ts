'use strict'
/**
 * AreaModel
 */
export default interface AreaModel{
    id?:any;
    country_id:any;
    code:string;
    name:string;
    createdDate?:Date;
    updateDate?:Date;
    deleteDate?:Date;
}